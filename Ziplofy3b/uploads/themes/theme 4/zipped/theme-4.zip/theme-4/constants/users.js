// Demo users
const USERS = [
  { id: 1, name: 'Alice Johnson', email: 'alice@example.com', contact: '+1 202 555 0147' },
  { id: 2, name: 'Bob Smith', email: 'bob@example.com', contact: '+1 202 555 0199' },
  { id: 3, name: 'Carol Lee', email: 'carol@example.com', contact: '+1 202 555 0175' }
];

