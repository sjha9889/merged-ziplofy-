// Product data constants
// const PRODUCTS = [
//   { id: 1, title: 'T-Shirt', price: 19.99, image: 'https://picsum.photos/seed/tshirt/400/300' },
//   { id: 2, title: 'Mug', price: 9.99, image: 'https://picsum.photos/seed/mug/400/300' },
//   { id: 3, title: 'Cap', price: 14.99, image: 'https://picsum.photos/seed/cap/400/300' }
// ];


// Product data constants
const PRODUCTS = [
  {
    id: 'sony-wh-1000xm4',
    title: 'Sony WH-1000XM4',
    category: 'Electronics',
    price: 24990,
    originalPrice: 32990,
    discount: 24,
    rating: 5,
    reviewCount: 2847,
    description: 'Industry-leading noise canceling headphones with exceptional sound quality and 30-hour battery life.',
    shortDescription: 'Industry-leading noise canceling...',
    features: [
      'Industry-leading noise cancellation',
      '30-hour battery life',
      'Quick charge (10 min = 5 hours)',
      'Touch sensor controls',
      'Speak-to-Chat technology'
    ],
    specifications: {
      'Type': 'Over-ear headphones',
      'Connectivity': 'Bluetooth 5.0, NFC',
      'Battery Life': '30 hours',
      'Weight': '254g',
      'Frequency Response': '4Hz - 40kHz',
      'Driver Unit': '40mm',
      'Noise Cancellation': 'Yes',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&h=900&fit=crop&crop=center',
    badge: 'Best Seller',
    inStock: true,
    colors: ['Black', 'Silver', 'Blue'],
    sizes: ['One Size']
  },
  {
    id: 'apple-watch-series-9',
    title: 'Apple Watch Series 9',
    category: 'Electronics',
    price: 45900,
    originalPrice: 49900,
    discount: 8,
    rating: 5,
    reviewCount: 1923,
    description: 'Most advanced Apple Watch with health monitoring, fitness tracking, and cellular connectivity.',
    shortDescription: 'Most advanced Apple Watch...',
    features: [
      'Always-on Retina display',
      'Health monitoring',
      'Fitness tracking',
      'Cellular connectivity',
      'Water resistant to 50 meters'
    ],
    specifications: {
      'Display': 'Always-on Retina LTPO OLED',
      'Size': '45mm',
      'Connectivity': 'GPS + Cellular',
      'Battery Life': 'Up to 18 hours',
      'Water Resistance': '50 meters',
      'Materials': 'Aluminum, Stainless Steel',
      'Sensors': 'Heart rate, ECG, Blood oxygen',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&h=900&fit=crop&crop=center',
    badge: 'New',
    inStock: true,
    colors: ['Midnight', 'Starlight', 'Pink', 'Blue'],
    sizes: ['41mm', '45mm']
  },
  {
    id: 'nike-air-max-270',
    title: 'Nike Air Max 270',
    category: 'Fashion',
    price: 12495,
    originalPrice: 15995,
    discount: 22,
    rating: 4,
    reviewCount: 3156,
    description: 'Comfortable lifestyle sneakers with Max Air cushioning for all-day comfort.',
    shortDescription: 'Comfortable lifestyle sneakers...',
    features: [
      'Max Air cushioning',
      'Breathable mesh upper',
      'Rubber outsole',
      'Lace-up closure',
      'Lightweight design'
    ],
    specifications: {
      'Type': 'Lifestyle sneakers',
      'Upper': 'Mesh and synthetic',
      'Midsole': 'Max Air cushioning',
      'Outsole': 'Rubber',
      'Closure': 'Lace-up',
      'Weight': '320g',
      'Heel Height': '32mm',
      'Warranty': '6 Months'
    },
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&h=900&fit=crop&crop=center',
    badge: 'Trending',
    inStock: true,
    colors: ['Black', 'White', 'Red', 'Blue'],
    sizes: ['7', '8', '9', '10', '11', '12']
  },
  {
    id: 'iphone-15-pro',
    title: 'iPhone 15 Pro',
    category: 'Electronics',
    price: 134900,
    originalPrice: 139900,
    discount: 4,
    rating: 5,
    reviewCount: 4892,
    description: 'Titanium design with A17 Pro chip, advanced camera system, and USB-C connectivity.',
    shortDescription: 'Titanium design with A17 Pro...',
    features: [
      'Titanium design',
      'A17 Pro chip',
      'Pro camera system',
      'USB-C connectivity',
      'Action Button'
    ],
    specifications: {
      'Display': '6.1-inch Super Retina XDR',
      'Chip': 'A17 Pro',
      'Storage': '128GB, 256GB, 512GB, 1TB',
      'Camera': '48MP Main, 12MP Ultra Wide, 12MP Telephoto',
      'Battery': 'Up to 23 hours video playback',
      'Materials': 'Titanium',
      'Connectivity': '5G, Wi-Fi 6E, Bluetooth 5.3',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=900&fit=crop&crop=center',
    badge: 'Limited',
    inStock: true,
    colors: ['Natural Titanium', 'Blue Titanium', 'White Titanium', 'Black Titanium'],
    sizes: ['128GB', '256GB', '512GB', '1TB']
  },
  {
    id: 'sony-wh-1000xm5',
    title: 'Sony WH-1000XM5',
    category: 'Electronics',
    price: 19990,
    originalPrice: 39990,
    discount: 50,
    rating: 5,
    reviewCount: 3247,
    description: 'Premium noise canceling headphones with industry-leading sound quality and comfort.',
    shortDescription: 'Premium noise canceling...',
    features: [
      'Industry-leading noise cancellation',
      '30-hour battery life',
      'Quick charge (3 min = 3 hours)',
      'Speak-to-Chat technology',
      'Multipoint connection'
    ],
    specifications: {
      'Type': 'Over-ear headphones',
      'Connectivity': 'Bluetooth 5.2, NFC',
      'Battery Life': '30 hours',
      'Weight': '250g',
      'Frequency Response': '4Hz - 40kHz',
      'Driver Unit': '30mm',
      'Noise Cancellation': 'Yes',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=1200&h=900&fit=crop&crop=center',
    badge: '50% OFF',
    inStock: true,
    colors: ['Black', 'Silver'],
    sizes: ['One Size']
  },
  {
    id: 'macbook-pro-m3',
    title: 'MacBook Pro M3',
    category: 'Electronics',
    price: 119900,
    originalPrice: 169900,
    discount: 30,
    rating: 5,
    reviewCount: 1856,
    description: 'Professional performance with M3 chip, stunning Liquid Retina XDR display, and all-day battery life.',
    shortDescription: 'Professional performance...',
    features: [
      'M3 chip with 8-core CPU',
      'Liquid Retina XDR display',
      'Up to 22 hours battery life',
      '1080p FaceTime HD camera',
      'Magic Keyboard with Touch ID'
    ],
    specifications: {
      'Chip': 'Apple M3',
      'Display': '14.2-inch Liquid Retina XDR',
      'Memory': '8GB, 16GB, 24GB',
      'Storage': '512GB, 1TB, 2TB, 4TB, 8TB',
      'Graphics': '8-core GPU',
      'Battery': 'Up to 22 hours',
      'Ports': '3x Thunderbolt 4, HDMI, SDXC, MagSafe 3',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=1200&h=900&fit=crop&crop=center',
    badge: '30% OFF',
    inStock: true,
    colors: ['Space Gray', 'Silver'],
    sizes: ['14-inch', '16-inch']
  },
  {
    id: 'nike-air-jordan-1',
    title: 'Nike Air Jordan 1',
    category: 'Fashion',
    price: 8997,
    originalPrice: 14995,
    discount: 40,
    rating: 4,
    reviewCount: 2891,
    description: 'Classic basketball sneakers with iconic design and premium materials.',
    shortDescription: 'Classic basketball...',
    features: [
      'Iconic basketball design',
      'Premium leather upper',
      'Air-Sole unit',
      'Rubber outsole',
      'High-top silhouette'
    ],
    specifications: {
      'Type': 'Basketball sneakers',
      'Upper': 'Premium leather',
      'Midsole': 'Air-Sole unit',
      'Outsole': 'Rubber',
      'Closure': 'Lace-up',
      'Weight': '400g',
      'Heel Height': '35mm',
      'Warranty': '6 Months'
    },
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&h=900&fit=crop&crop=center',
    badge: '40% OFF',
    inStock: true,
    colors: ['Bred', 'Chicago', 'Royal', 'Shadow'],
    sizes: ['7', '8', '9', '10', '11', '12']
  },
  {
    id: 'samsung-galaxy-s24-ultra',
    title: 'Samsung Galaxy S24 Ultra',
    category: 'Electronics',
    price: 89999,
    originalPrice: 119999,
    discount: 25,
    rating: 5,
    reviewCount: 4123,
    description: 'Advanced AI smartphone with S Pen, 200MP camera, and titanium design.',
    shortDescription: 'Advanced AI smartphone...',
    features: [
      'S Pen included',
      '200MP camera system',
      'Titanium design',
      'AI-powered features',
      '5G connectivity'
    ],
    specifications: {
      'Display': '6.8-inch Dynamic AMOLED 2X',
      'Chip': 'Snapdragon 8 Gen 3',
      'Storage': '256GB, 512GB, 1TB',
      'Camera': '200MP Main, 50MP Periscope, 10MP Telephoto, 12MP Ultra Wide',
      'Battery': '5000mAh',
      'Materials': 'Titanium',
      'Connectivity': '5G, Wi-Fi 7, Bluetooth 5.3',
      'Warranty': '1 Year'
    },
    images: [
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=1200&h=900&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=1200&h=900&fit=crop&crop=center'
    ],
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=900&fit=crop&crop=center',
    badge: '25% OFF',
    inStock: true,
    colors: ['Titanium Black', 'Titanium Gray', 'Titanium Violet', 'Titanium Yellow'],
    sizes: ['256GB', '512GB', '1TB']
  }
];

// ==== Product helpers (single source) ====
// Normalize a product to shape used across the site
function normalizeProductShape(p) {
  if (!p) return null;
  const image = p.image || (Array.isArray(p.images) && p.images.length ? p.images[0] : '');
  const name = p.name || p.title || '';
  const category = (p.category || '').toString().toLowerCase();
  const badges = [];
  if (p.badge) {
    badges.push(p.badge.toString().toLowerCase());
  }
  const categoryLabel = category ? category.charAt(0).toUpperCase() + category.slice(1) : '';
  return {
    id: p.id,
    name: name,
    title: p.title || name,
    image: image,
    images: Array.isArray(p.images) ? p.images : (image ? [image] : []),
    category: category,
    categoryLabel: p.categoryLabel || categoryLabel,
    price: typeof p.price === 'number' ? p.price : 0,
    originalPrice: typeof p.originalPrice === 'number' ? p.originalPrice : null,
    discount: typeof p.discount === 'number' ? p.discount : 0,
    rating: typeof p.rating === 'number' ? p.rating : 0,
    reviewCount: typeof p.reviewCount === 'number' ? p.reviewCount : 0,
    inStock: typeof p.inStock === 'boolean' ? p.inStock : true,
    badges: badges,
    description: p.description || '',
    shortDescription: p.shortDescription || '',
    features: Array.isArray(p.features) ? p.features : [],
    specifications: p.specifications || {},
    colors: Array.isArray(p.colors) ? p.colors : [],
    sizes: Array.isArray(p.sizes) ? p.sizes : []
  };
}

function getAllProducts() {
  return (PRODUCTS || []).map(normalizeProductShape);
}

function getProductById(id) {
  const list = getAllProducts();
  return list.find(p => String(p.id) === String(id));
}

function getProductsByCategory(category) {
  const cat = (category || '').toString().toLowerCase();
  return getAllProducts().filter(p => p.category === cat);
}

function getTrendingProducts() {
  return getAllProducts().slice(0, 8);
}

function getNewProducts() {
  return getAllProducts().slice(2, 10);
}

function getSaleProducts() {
  return getAllProducts().filter(p => p.originalPrice && p.originalPrice > p.price).slice(0, 8);
}

function getFeaturedProducts() {
  return getAllProducts().filter(p => p.rating >= 4.5).slice(0, 8);
}

function getBestsellerProducts() {
  return getAllProducts().filter(p => p.rating >= 4.8).slice(0, 8);
}

function getHotProducts() {
  return getAllProducts().filter(p => p.discount >= 20).slice(0, 8);
}

// Expose globally for existing scripts
window.getAllProducts = getAllProducts;
window.getProductById = getProductById;
window.getProductsByCategory = getProductsByCategory;
window.getTrendingProducts = getTrendingProducts;
window.getNewProducts = getNewProducts;
window.getSaleProducts = getSaleProducts;
window.getFeaturedProducts = getFeaturedProducts;
window.getBestsellerProducts = getBestsellerProducts;
window.getHotProducts = getHotProducts;